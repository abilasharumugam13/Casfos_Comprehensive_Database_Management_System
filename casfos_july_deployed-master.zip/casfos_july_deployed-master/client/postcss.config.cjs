module.exports = {
  plugins: {
    '@tailwindcss/postcss': {}, // Use the new package
    autoprefixer: {},
  },
};