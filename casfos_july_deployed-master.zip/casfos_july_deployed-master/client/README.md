# React + Vite

This template provides a minimal setup to get React working in Vite with HMR and some ESLint rules.

Currently, two official plugins are available:

- [@vitejs/plugin-react](http://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react/README.md) uses [Babel](http://babeljs.io/) for Fast Refresh
- [@vitejs/plugin-react-swc](http://github.com/vitejs/vite-plugin-react-swc) uses [SWC](http://swc.rs/) for Fast Refresh
